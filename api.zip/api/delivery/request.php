<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../middleware/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit(); }

$user = authenticate();
$data = json_decode(file_get_contents('php://input'), true);
$gold_grams = (float)($data['gold_grams'] ?? 0);
$address = trim($data['address'] ?? '');

if ($gold_grams < MIN_GOLD_DELIVERY_GRAMS) {
    echo json_encode(['success' => false, 'message' => 'Minimum delivery is 1 gram']); exit();
}
if (strlen($address) < 10) {
    echo json_encode(['success' => false, 'message' => 'Please provide full delivery address']); exit();
}

$db = (new Database())->getConnection();
$summary = $db->prepare("SELECT total_gold_grams FROM user_gold_summary WHERE user_id=?");
$summary->execute([$user['id']]);
$balance = $summary->fetch();

if (!$balance || $balance['total_gold_grams'] < $gold_grams) {
    echo json_encode(['success' => false, 'message' => 'Insufficient gold balance']); exit();
}

$rate = $db->query("SELECT rate_per_gram FROM gold_rates ORDER BY rate_date DESC LIMIT 1")->fetch();

$db->beginTransaction();
$txn = $db->prepare("INSERT INTO transactions (user_id, type, gold_grams, gold_rate, status) VALUES (?, 'delivery', ?, ?, 'pending')");
$txn->execute([$user['id'], $gold_grams, $rate['rate_per_gram']]);
$txn_id = $db->lastInsertId();

$del = $db->prepare("INSERT INTO delivery_requests (user_id, transaction_id, gold_grams, delivery_address, delivery_city, delivery_state, delivery_pincode) VALUES (?, ?, ?, ?, ?, ?, ?)");
$del->execute([$user['id'], $txn_id, $gold_grams, $address, $data['city'] ?? '', $data['state'] ?? '', $data['pincode'] ?? '']);
$db->commit();

$db->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, 'Delivery Requested', ?, 'delivery')")
   ->execute([$user['id'], "Delivery request for {$gold_grams}g gold has been placed"]);

echo json_encode(['success' => true, 'message' => 'Delivery request submitted', 'data' => ['transaction_id' => $txn_id]]);
